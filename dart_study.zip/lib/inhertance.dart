void main(){
Idol apink = Idol(name: '에이핑크', memberCount: 4);

apink.sayMemberCount();
apink.sayName();

BoyGroup bts = BoyGroup('bts', 10);
bts.sayMemberCount();
}

//상속
class Idol{
  String name;
  int memberCount;
  Idol({
    required this.name,
    required this.memberCount,
});
  void sayName(){
    print('저는 ${this.name}입니다');
  }
  void sayMemberCount(){
    print('${this.name}의 멥버는 ${this.memberCount}명 입니다');
  }
}

class BoyGroup extends Idol{
  //상속시 생성자 맞춰줘야한다
  BoyGroup(
    String name,
    int memberCount,
    ): super(
      name: name,
      memberCount: memberCount,
      );
}