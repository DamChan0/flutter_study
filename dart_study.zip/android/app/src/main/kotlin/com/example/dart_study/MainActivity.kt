package com.example.dart_study

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
